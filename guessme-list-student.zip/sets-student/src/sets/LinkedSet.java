package sets;

import java.util.Iterator;

/**
 * A LinkedList-based implementation of Set
 */

  /********************************************************
   * NOTE: Before you start, check the Set interface in
   * Set.java for detailed description of each method.
   *******************************************************/
  
  /********************************************************
   * NOTE: for this project you must use linked lists
   * implemented by yourself. You are NOT ALLOWED to use
   * Java arrays of any type, or any Collection-based class 
   * such as ArrayList, Vector etc. You will receive a 0
   * if you use any of them.
   *******************************************************/ 

  /********************************************************
   * NOTE: you are allowed to add new methods if necessary,
   * but do NOT add new files (as they will be ignored).
   *******************************************************/

public class LinkedSet<E> implements Set<E> {
  private LinkedNode<E> head = null;

  // Constructors
  public LinkedSet() {
	 
  }

  public LinkedSet(E e) {
    this.head = new LinkedNode<E>(e, null);
  }
  // call this constructer from other methods
  private LinkedSet(LinkedNode<E> head) {
    this.head = head;
    
    
    
  }

  @Override
  public int size() {
	 int counter = 0;
    // TODO (1)
	LinkedNode<E> node = head;
	while (node !=null) {
		counter++;
		node = node.getNext();
		
	}	 
    return counter;
  }

  @Override
  public boolean isEmpty() {
    // TODO (2)
	if (this.size() == 0) {
		return true;
	}
	
    return false;
  }

  @Override
  public Iterator<E> iterator() {
    return new LinkedNodeIterator<E>(this.head);
  }

  @Override
  public boolean contains(Object o) {
    // TODO (3)
	  LinkedNode<E> node = head;
	  while (node != null) {
		  if (node.getData() == o) {
			  return true;
		  }
		node = node.getNext();
	  }
    return false;
  }

  @Override
  public boolean isSubset(Set<E> that) {
    // TODO (4)
	  int count = 0;
	  for (E node: this) {
		if (that.contains(node)) {
			count++;
		}
	  }
	  if (count == this.size()) {
		  return true;
	  }
	  
    return false;
  }

  @Override
  public boolean isSuperset(Set<E> that) {
	  int count = 0;
	  for (E node: that) {
		if (this.contains(node)) {
			count++;
		}
	  }
	  if (count == that.size()) {
		  return true;
	  }
	  
    return false;
  }
    // TODO (5)
	  
  
  

  @Override
  public Set<E> adjoin(E e) {
 	 
		  if (this.contains(e)) {
			  return this;
		  }
		  LinkedNode<E> node = new LinkedNode<E>(e,head);
				  
		  LinkedSet<E> temp = new LinkedSet<E>(node);
		  
	  
    // TODO (6)
    return temp;
  }

  @Override
  public Set<E> union(Set<E> that) {
    // TODO (7)
	  Set<E> set = new LinkedSet<E>();
	  if (this.size() == 0) {
		  return that;
	  }
	  if (that.size() == 0) {
		  return this;
	  }
	  for (E node: that) {
		  set = set.adjoin(node);
	  }
	  for (E node: this) {
		  set = set.adjoin(node);
	  }
	  
    return set;
  }

  @Override
  public Set<E> intersect(Set<E> that) {
    // TODO (8)
	Set<E> set = new LinkedSet<E>();
	if (this.size() == 0) {
		return set;
	}
	if (that.size() == 0) {
		return set;
	}
	
	for (E node: that) {
		if (this.contains(node)) {
			set = set.adjoin(node);
		}
	}
    return set;
  }

  @Override
  public Set<E> subtract(Set<E> that) {
    // TODO (9)
	Set<E> set = new LinkedSet<E>();
	for (E node: this) {
		if (that.contains(node) == false) {
			set = set.adjoin(node);
		}
  }
    return set;
  }

  @Override
  public Set<E> remove(E e) {
    // TODO (10)
	  Set<E> set = new LinkedSet<E>();
	  for (E node :this) {
		  if (node != e) {
			 set = set.adjoin(node);
		  }
	  }
    return set;
  }

  @Override
  @SuppressWarnings("unchecked")
  public boolean equals(Object o) {
    if (! (o instanceof Set)) {
      return false;
    }
    Set<E> that = (Set<E>)o;
    return this.isSubset(that) && that.isSubset(this);
  }

  @Override
    public int hashCode() {
    int result = 0;
    for (E e : this) {
      result += e.hashCode();
    }
    return result;
  }
}
